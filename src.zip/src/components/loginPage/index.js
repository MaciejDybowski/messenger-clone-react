import LoginPage from './LoginPage'

export default LoginPage;